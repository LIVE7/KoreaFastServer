nohup ./server.sh 2>&1 >> error.log &
